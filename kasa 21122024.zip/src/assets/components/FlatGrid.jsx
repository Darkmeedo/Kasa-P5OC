import React from 'react';
import "./FlatGrid.css";
import Flat from "./Flat.jsx";


function FlatGrid() {
  return (
    <div className="grid">
        <Flat />
        <Flat />
        <Flat />
        <Flat />
        <Flat />
        <Flat />
        <Flat />
        <Flat />
        <Flat />
        <Flat />
        <Flat />
        <Flat />
    </div>
  )
}

export default FlatGrid;
