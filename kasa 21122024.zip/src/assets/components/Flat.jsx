import React from 'react';
import "./Flat.css";
import {Link} from "react-router-dom";
import {NavLink} from "react-router-dom";

function Flat() {
  return (
    <div className="Flat">
    <NavLink to="/flat">  
      <div className="Flat__Name">Titre de la location</div>
    </NavLink>
    </div>
  )
}

export default Flat
