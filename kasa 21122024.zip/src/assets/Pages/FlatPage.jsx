import React, { useState } from 'react';
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import "./FlatPage.css";
import "../components/Summary.css";
import Summary from '../components/Summary';
import Carousel from '../components/Carousel';

function FlatPage() {
  const [showDescription, setShowDescription] = useState(false);
  const [showEquipments, setShowEquipments] = useState(false);

  return (
    <div className="Appartment">
      <Navbar />
      <div className="FlatPic">
        <Carousel />
      </div>
      <div className="FlatContent">
        <div className="FlatSpecs">
          <h1>Crazy Loft on Canal Saint Martin</h1>
          <h2>Paris, île de France</h2>
          <div className="tags">
            <p>Cozy</p>
            <p>Canal</p>
            <p>Paris 10</p>
          </div>
        </div>

        <div className="Flat-Owner">
          <div className="Flat-Owner-Top">
            <h3>Alexandre Dumas</h3>
            <div className="Flat-Owner-Pic">
              <img src="https://picsum.photos/50/50" alt="Flat-owner" />
            </div>
          </div>
          <div className="Flat-Rate">
            <span>★</span>
            <span>★</span>
            <span>★</span>
            <span className="inactive">★</span>
            <span className="inactive">★</span>
          </div>
        </div>
      </div>

      <div className="Flat-Menus">
        
        <Summary
          title="Description"
          content={
            <p>
              Vous serez à 50m du canal Saint-Martin où vous pourrez pique-niquer l'été à côté de nombreux bars et restaurants.
              Au coeur de Paris avec 5 lignes de métro et de nombreux bus. Logement parfait pour les voyageurs en solo et les voyageurs d'affaires.
              Vous êtes à 1 station de la gare de l'Est (7 minutes à pieds).
            </p>
          }
          isOpen={showDescription}
          toggleContent={() => setShowDescription(!showDescription)}
        />

  
        <Summary
          title="Equipement"
          content={
            <ul>
              <li>Climatisation</li>
              <li>Wi-Fi</li>
              <li>Cuisine</li>
              <li>Espace de travail</li>
              <li>Fer à repasser</li>
              <li>Sèche-cheveux</li>
              <li>Cintres</li>
            </ul>
          }
          isOpen={showEquipments}
          toggleContent={() => setShowEquipments(!showEquipments)}
        />
      </div>

      <Footer />
    </div>
  );
}

export default FlatPage;
